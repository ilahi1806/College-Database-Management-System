<?php

$config = [
    'components' => [
        'db'=> [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=its',
            'username' => 'root', //root
            'password' => '',
            'charset' => 'utf8',
        ],
        'db1'=> [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=its_backend',
            'username' => 'root', //root
            'password' => '',
            'charset' => 'utf8',
        ],
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '45zf0fxfFxrm0va_VpL7McnEXKpvruzp',
        ],
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
