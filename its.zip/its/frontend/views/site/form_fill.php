
<style> 
body{
    background-color:lavender;
}
</style>
<body>
<?php
echo "FORM SUCCESSFULLY SUBMITTED !!!";
?>
</body>