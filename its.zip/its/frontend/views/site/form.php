<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Data */
/* @var $form ActiveForm */
?>
<style> 
body{
    background-color:lavender;
}
</style>
<body>
<div class="site-form">
    <h1>REGISTRATION FORM</h1>
    <p>
    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'email') ?>
        <?= $form->field($model, 'name') ?>
        <?= $form->field($model, 'year') ?>
        <?= $form->field($model, 'roll_no') ?>
        <?= $form->field($model, 'mobile') ?>
        <?= $form->field($model, 'gender') ?>
        <?= $form->field($model, 'address') ?>

        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
    </p>

</div><!-- site-form -->
</body>
