<div>
    <h1>RESULT</h1>
</div>
<?php
// use Yii;

use common\models\User;
use app\models\Marks;
use app\controllers;
use app\models\MarksSearch;
use yii\db\ActiveQuery;
use common\config;
use yii\frontend\models;

// $query=Yii::$app->db1->createCommand('select * from marks  where name="ilahi"')->execute();
// $query=Yii::$app->db1->ActiveQuery('select * from marks  where name="ilahi"');

$user = Yii::$app->user->identity->username;


// $result = Querydata();
echo "username = $user";
// echo "<br><br>";
// $sql="SELECT * FROM marks WHERE name = '$user'";
// // $rr=Yii::$app->db1->$quer
// // $result= Yii::$app->db1->;
// // new Query()->select()
// $result= Marks::find()->all();
// echo "<br><br>";
// echo "<table border='5'>";
// echo "<tr><td>email</td><td>name</td><td>roll_no</td><td>SE</td><td>PPL</td><td>MATHS_3</td><td>DSA</td><td>Microprocessor</td></tr>";
// foreach ($result as $row => $key)
// {
//     // echo "<tr><td>$row['name']</td><td>$row['roll_no']</td><td>$row['SE']</td><td>$row['PPL']</td><td>$row['MATHS_3']</td><td>$row['DSA']</td><td>$row['Microprocessor']</td></tr>";
//     // echo "$key";
//     echo "<br><br>";
//     echo "$row['name']";
//     echo "<br><br>";
// }
// echo "</table>";

// echo "$result";
?>

<style>
    body {
        background-color:lavender;
    }
</style>
