<style> 
body{
    background-color:lavender;
}
</style>
<body>
    <?php
echo "Form Successfully Submitted !!!";
?>
</body>