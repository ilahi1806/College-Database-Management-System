<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Marks */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="marks-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'roll_no')->textInput() ?>

    <?= $form->field($model, 'SE')->textInput() ?>

    <?= $form->field($model, 'PPL')->textInput() ?>

    <?= $form->field($model, 'MATHS_3')->textInput() ?>

    <?= $form->field($model, 'DSA')->textInput() ?>

    <?= $form->field($model, 'Microprocessor')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
