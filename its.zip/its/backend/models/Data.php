<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "data".
 *
 * @property string $email
 * @property string $name
 * @property string $year
 * @property int $roll_no
 * @property int $mobile
 * @property string $gender
 * @property string $address
 */
class Data extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'data';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db2');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email', 'name', 'year', 'roll_no', 'mobile', 'gender', 'address'], 'required'],
            [['roll_no', 'mobile'], 'integer'],
            [['email', 'name', 'year'], 'string', 'max' => 50],
            [['gender'], 'string', 'max' => 10],
            [['address'], 'string', 'max' => 500],
            [['roll_no'], 'unique'],
            [['email'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'email' => 'Email',
            'name' => 'Name',
            'year' => 'Year',
            'roll_no' => 'Roll No',
            'mobile' => 'Mobile',
            'gender' => 'Gender',
            'address' => 'Address',
        ];
    }
}
