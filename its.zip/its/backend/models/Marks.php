<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "marks".
 *
 * @property string $email
 * @property string $name
 * @property int $roll_no
 * @property int|null $SE
 * @property int|null $PPL
 * @property int|null $MATHS_3
 * @property int|null $DSA
 * @property int|null $Microprocessor
 */
class Marks extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'marks';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db1');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email', 'name', 'roll_no'], 'required'],
            [['roll_no', 'SE', 'PPL', 'MATHS_3', 'DSA', 'Microprocessor'], 'integer'],
            [['email', 'name'], 'string', 'max' => 50],
            [['name'], 'unique'],
            [['roll_no'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'email' => 'Email',
            'name' => 'Name',
            'roll_no' => 'Roll No',
            'SE' => 'Se',
            'PPL' => 'Ppl',
            'MATHS_3' => 'Maths  3',
            'DSA' => 'Dsa',
            'Microprocessor' => 'Microprocessor',
        ];
    }
}
